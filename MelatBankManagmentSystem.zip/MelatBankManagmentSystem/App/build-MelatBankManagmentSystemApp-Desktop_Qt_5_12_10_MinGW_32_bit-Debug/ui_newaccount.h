/********************************************************************************
** Form generated from reading UI file 'newaccount.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWACCOUNT_H
#define UI_NEWACCOUNT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_NewAccount
{
public:
    QLabel *label;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLineEdit *lineEdit;
    QLabel *label_10;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_8;

    void setupUi(QDialog *NewAccount)
    {
        if (NewAccount->objectName().isEmpty())
            NewAccount->setObjectName(QString::fromUtf8("NewAccount"));
        NewAccount->setEnabled(true);
        NewAccount->resize(1062, 638);
        NewAccount->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);"));
        label = new QLabel(NewAccount);
        label->setObjectName(QString::fromUtf8("label"));
        label->setEnabled(true);
        label->setGeometry(QRect(20, 20, 1031, 161));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_3 = new QLabel(NewAccount);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(350, 50, 327, 110));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/pref2/bank melat.jpg")));
        label_3->setScaledContents(true);
        label_2 = new QLabel(NewAccount);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setEnabled(true);
        label_2->setGeometry(QRect(20, 190, 1031, 431));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_4 = new QLabel(NewAccount);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 200, 1001, 231));
        label_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_5 = new QLabel(NewAccount);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(860, 220, 151, 31));
        label_5->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_6 = new QLabel(NewAccount);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(860, 260, 151, 31));
        label_6->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_7 = new QLabel(NewAccount);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(860, 300, 151, 31));
        label_7->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_8 = new QLabel(NewAccount);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(860, 340, 151, 31));
        label_8->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_9 = new QLabel(NewAccount);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(860, 380, 151, 31));
        label_9->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        lineEdit = new QLineEdit(NewAccount);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(640, 220, 211, 31));
        lineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        label_10 = new QLabel(NewAccount);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(290, 220, 151, 31));
        label_10->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        lineEdit_2 = new QLineEdit(NewAccount);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(640, 260, 211, 31));
        lineEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lineEdit_3 = new QLineEdit(NewAccount);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(640, 300, 211, 31));
        lineEdit_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lineEdit_4 = new QLineEdit(NewAccount);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(640, 340, 211, 31));
        lineEdit_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lineEdit_5 = new QLineEdit(NewAccount);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(640, 380, 211, 31));
        lineEdit_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        label_11 = new QLabel(NewAccount);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(290, 280, 151, 31));
        label_11->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_12 = new QLabel(NewAccount);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(290, 340, 151, 31));
        label_12->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_13 = new QLabel(NewAccount);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(290, 380, 151, 31));
        label_13->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        lineEdit_6 = new QLineEdit(NewAccount);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(70, 220, 211, 31));
        lineEdit_6->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lineEdit_7 = new QLineEdit(NewAccount);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(70, 340, 211, 31));
        lineEdit_7->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lineEdit_8 = new QLineEdit(NewAccount);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(70, 380, 211, 31));
        lineEdit_8->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        label->raise();
        label_2->raise();
        label_4->raise();
        label_5->raise();
        label_6->raise();
        label_7->raise();
        label_8->raise();
        label_9->raise();
        lineEdit->raise();
        label_10->raise();
        lineEdit_2->raise();
        lineEdit_3->raise();
        lineEdit_4->raise();
        lineEdit_5->raise();
        label_11->raise();
        label_12->raise();
        label_13->raise();
        lineEdit_6->raise();
        lineEdit_7->raise();
        lineEdit_8->raise();
        label_3->raise();

        retranslateUi(NewAccount);

        QMetaObject::connectSlotsByName(NewAccount);
    } // setupUi

    void retranslateUi(QDialog *NewAccount)
    {
        NewAccount->setWindowTitle(QApplication::translate("NewAccount", "Dialog", nullptr));
        label->setText(QString());
        label_3->setText(QString());
        label_2->setText(QString());
        label_4->setText(QString());
        label_5->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\331\206\330\247\331\205</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\331\206\330\247\331\205 \330\256\330\247\331\206\331\210\330\247\330\257\332\257\333\214</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\">\330\252\330\247\330\261\333\214\330\256 \330\252\331\210\331\204\330\257</p></body></html>", nullptr));
        label_8->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\332\251\330\257 \331\205\331\204\333\214</span></p></body></html>", nullptr));
        label_9->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\331\206\330\247\331\205 \331\276\330\257\330\261</span></p></body></html>", nullptr));
        label_10->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\">\330\264\331\205\330\247\330\261\331\207 \330\255\330\263\330\247\330\250</p></body></html>", nullptr));
        label_11->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\331\206\331\210\330\271 \330\255\330\263\330\247\330\250</span></p></body></html>", nullptr));
        label_12->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\330\264\331\205\330\247\330\261\331\207 \332\251\330\247\330\261\330\252</span></p></body></html>", nullptr));
        label_13->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\331\205\331\210\330\254\331\210\330\257\333\214 \330\255\330\263\330\247\330\250</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NewAccount: public Ui_NewAccount {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWACCOUNT_H
