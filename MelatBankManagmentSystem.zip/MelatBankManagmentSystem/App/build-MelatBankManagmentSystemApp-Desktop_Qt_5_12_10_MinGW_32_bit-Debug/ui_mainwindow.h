/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_4;
    QLabel *label_5;
    QPushButton *pushButtonClose;
    QPushButton *pushButtonLogin;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1062, 638);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 20, 1021, 231));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(88, 88, 88);"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 270, 1021, 331));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(113, 113, 113);\n"
"background-color: rgb(86, 86, 86);"));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(350, 90, 391, 121));
        label_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_4->setPixmap(QPixmap(QString::fromUtf8(":/pref4/bakn.jpg")));
        label_4->setScaledContents(true);
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(220, 300, 621, 81));
        label_5->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 170, 255);"));
        pushButtonClose = new QPushButton(centralwidget);
        pushButtonClose->setObjectName(QString::fromUtf8("pushButtonClose"));
        pushButtonClose->setGeometry(QRect(640, 450, 331, 71));
        QFont font;
        font.setPointSize(16);
        font.setBold(false);
        font.setWeight(50);
        pushButtonClose->setFont(font);
        pushButtonClose->setCursor(QCursor(Qt::PointingHandCursor));
        pushButtonClose->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        pushButtonClose->setIconSize(QSize(30, 30));
        pushButtonLogin = new QPushButton(centralwidget);
        pushButtonLogin->setObjectName(QString::fromUtf8("pushButtonLogin"));
        pushButtonLogin->setGeometry(QRect(70, 450, 331, 71));
        pushButtonLogin->setFont(font);
        pushButtonLogin->setCursor(QCursor(Qt::PointingHandCursor));
        pushButtonLogin->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 170, 0);"));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1062, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QString());
        label_2->setText(QApplication::translate("MainWindow", "<html><head/><body><p><br/></p></body></html>", nullptr));
        label_4->setText(QString());
        label_5->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt; font-weight:600; color:#ffffff;\">\330\250\331\207 \330\263\333\214\330\263\330\252\331\205 \331\207\331\210\330\264\331\205\331\206\330\257 \331\205\330\257\333\214\330\261\333\214\330\252 \330\250\330\247\331\206\332\251 \331\205\331\204\330\252 \330\256\331\210\330\264 \330\242\331\205\330\257\333\214\330\257</span></p></body></html>", nullptr));
        pushButtonClose->setText(QApplication::translate("MainWindow", "\330\256\330\261\331\210\330\254", nullptr));
        pushButtonLogin->setText(QApplication::translate("MainWindow", "\331\210\330\261\331\210\330\257", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
