/********************************************************************************
** Form generated from reading UI file 'loginemployeeform.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINEMPLOYEEFORM_H
#define UI_LOGINEMPLOYEEFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_LoginEmployeeForm
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QPushButton *pushButtonLogin;
    QPushButton *pushButtonBack;
    QPushButton *pushButton;
    QLineEdit *usernameLine;
    QLineEdit *passwordnameLine;

    void setupUi(QDialog *LoginEmployeeForm)
    {
        if (LoginEmployeeForm->objectName().isEmpty())
            LoginEmployeeForm->setObjectName(QString::fromUtf8("LoginEmployeeForm"));
        LoginEmployeeForm->resize(1062, 671);
        LoginEmployeeForm->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 4);"));
        label = new QLabel(LoginEmployeeForm);
        label->setObjectName(QString::fromUtf8("label"));
        label->setEnabled(true);
        label->setGeometry(QRect(20, 20, 1021, 171));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_2 = new QLabel(LoginEmployeeForm);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 200, 1021, 461));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_3 = new QLabel(LoginEmployeeForm);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(350, 50, 361, 111));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/pref2/bank melat.jpg")));
        label_3->setScaledContents(true);
        label_4 = new QLabel(LoginEmployeeForm);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(130, 240, 801, 211));
        label_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 255, 255);"));
        label_4->setMargin(5);
        label_5 = new QLabel(LoginEmployeeForm);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(710, 260, 201, 81));
        label_5->setStyleSheet(QString::fromUtf8("font: 16pt \"MS Shell Dlg 2\";"));
        label_6 = new QLabel(LoginEmployeeForm);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(710, 350, 201, 81));
        label_6->setStyleSheet(QString::fromUtf8("font: 16pt \"MS Shell Dlg 2\";"));
        pushButtonLogin = new QPushButton(LoginEmployeeForm);
        pushButtonLogin->setObjectName(QString::fromUtf8("pushButtonLogin"));
        pushButtonLogin->setGeometry(QRect(60, 500, 161, 81));
        QFont font;
        font.setPointSize(16);
        pushButtonLogin->setFont(font);
        pushButtonLogin->setCursor(QCursor(Qt::PointingHandCursor));
        pushButtonLogin->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 170, 0);"));
        pushButtonBack = new QPushButton(LoginEmployeeForm);
        pushButtonBack->setObjectName(QString::fromUtf8("pushButtonBack"));
        pushButtonBack->setGeometry(QRect(230, 500, 161, 81));
        pushButtonBack->setFont(font);
        pushButtonBack->setCursor(QCursor(Qt::PointingHandCursor));
        pushButtonBack->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 145, 20);\n"
"color: rgb(255, 255, 255);"));
        pushButton = new QPushButton(LoginEmployeeForm);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(400, 500, 161, 81));
        pushButton->setFont(font);
        pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);\n"
"color: rgb(255, 255, 255);"));
        usernameLine = new QLineEdit(LoginEmployeeForm);
        usernameLine->setObjectName(QString::fromUtf8("usernameLine"));
        usernameLine->setGeometry(QRect(152, 260, 551, 81));
        QFont font1;
        font1.setPointSize(11);
        usernameLine->setFont(font1);
        usernameLine->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        passwordnameLine = new QLineEdit(LoginEmployeeForm);
        passwordnameLine->setObjectName(QString::fromUtf8("passwordnameLine"));
        passwordnameLine->setGeometry(QRect(152, 350, 551, 81));
        passwordnameLine->setFont(font1);
        passwordnameLine->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        retranslateUi(LoginEmployeeForm);

        QMetaObject::connectSlotsByName(LoginEmployeeForm);
    } // setupUi

    void retranslateUi(QDialog *LoginEmployeeForm)
    {
        LoginEmployeeForm->setWindowTitle(QApplication::translate("LoginEmployeeForm", "Dialog", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        label_3->setText(QString());
        label_4->setText(QString());
        label_5->setText(QApplication::translate("LoginEmployeeForm", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; color:#ffffff;\">\331\206\330\247\331\205 \332\251\330\247\330\261\330\250\330\261\333\214</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("LoginEmployeeForm", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; color:#ffffff;\">\330\261\331\205\330\262 \330\271\330\250\331\210\330\261</span></p></body></html>", nullptr));
        pushButtonLogin->setText(QApplication::translate("LoginEmployeeForm", "\331\210\330\261\331\210\330\257", nullptr));
        pushButtonBack->setText(QApplication::translate("LoginEmployeeForm", "\330\250\330\261\332\257\330\264\330\252", nullptr));
        pushButton->setText(QApplication::translate("LoginEmployeeForm", "\330\256\330\261\331\210\330\254", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginEmployeeForm: public Ui_LoginEmployeeForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINEMPLOYEEFORM_H
