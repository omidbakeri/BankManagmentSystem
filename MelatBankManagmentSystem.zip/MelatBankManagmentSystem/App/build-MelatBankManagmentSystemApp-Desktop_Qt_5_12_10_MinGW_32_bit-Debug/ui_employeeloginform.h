/********************************************************************************
** Form generated from reading UI file 'employeeloginform.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMPLOYEELOGINFORM_H
#define UI_EMPLOYEELOGINFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_EmployeeLoginForm
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QDialog *EmployeeLoginForm)
    {
        if (EmployeeLoginForm->objectName().isEmpty())
            EmployeeLoginForm->setObjectName(QString::fromUtf8("EmployeeLoginForm"));
        EmployeeLoginForm->resize(1062, 638);
        EmployeeLoginForm->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);"));
        label = new QLabel(EmployeeLoginForm);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 20, 1021, 191));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(88, 88, 88);"));
        label_2 = new QLabel(EmployeeLoginForm);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 220, 1021, 401));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(88, 88, 88);"));
        label_3 = new QLabel(EmployeeLoginForm);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(320, 60, 441, 121));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/pref2/bank melat.jpg")));
        label_3->setScaledContents(true);
        label_4 = new QLabel(EmployeeLoginForm);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(170, 260, 741, 211));
        label_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_5 = new QLabel(EmployeeLoginForm);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(670, 280, 231, 81));
        label_6 = new QLabel(EmployeeLoginForm);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(670, 370, 231, 81));
        lineEdit = new QLineEdit(EmployeeLoginForm);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(200, 280, 461, 81));
        QFont font;
        font.setPointSize(16);
        lineEdit->setFont(font);
        lineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 85, 255);"));
        lineEdit_2 = new QLineEdit(EmployeeLoginForm);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(200, 370, 461, 81));
        lineEdit_2->setFont(font);
        lineEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 85, 255);"));
        pushButton = new QPushButton(EmployeeLoginForm);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(70, 510, 161, 81));
        pushButton->setFont(font);
        pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 170, 0);"));
        pushButton_2 = new QPushButton(EmployeeLoginForm);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(240, 510, 161, 81));
        pushButton_2->setFont(font);
        pushButton_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 133, 33);"));
        pushButton_3 = new QPushButton(EmployeeLoginForm);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(410, 510, 161, 81));
        pushButton_3->setFont(font);
        pushButton_3->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 0, 0);"));

        retranslateUi(EmployeeLoginForm);

        QMetaObject::connectSlotsByName(EmployeeLoginForm);
    } // setupUi

    void retranslateUi(QDialog *EmployeeLoginForm)
    {
        EmployeeLoginForm->setWindowTitle(QApplication::translate("EmployeeLoginForm", "Dialog", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        label_3->setText(QString());
        label_4->setText(QString());
        label_5->setText(QApplication::translate("EmployeeLoginForm", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; color:#ffffff;\">\331\206\330\247\331\205 \332\251\330\247\330\261\330\250\330\261\333\214</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("EmployeeLoginForm", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; color:#ffffff;\">\330\261\331\205\330\262 \330\271\330\250\331\210\330\261</span></p></body></html>", nullptr));
        pushButton->setText(QApplication::translate("EmployeeLoginForm", "\331\210\330\261\331\210\330\257", nullptr));
        pushButton_2->setText(QApplication::translate("EmployeeLoginForm", "\330\250\330\261\332\257\330\264\330\252", nullptr));
        pushButton_3->setText(QApplication::translate("EmployeeLoginForm", "\330\256\330\261\331\210\330\254", nullptr));
    } // retranslateUi

};

namespace Ui {
    class EmployeeLoginForm: public Ui_EmployeeLoginForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMPLOYEELOGINFORM_H
