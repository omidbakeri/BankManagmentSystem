/********************************************************************************
** Form generated from reading UI file 'melatanksystemlogin.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MELATANKSYSTEMLOGIN_H
#define UI_MELATANKSYSTEMLOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_MelatankSystemLogin
{
public:

    void setupUi(QDialog *MelatankSystemLogin)
    {
        if (MelatankSystemLogin->objectName().isEmpty())
            MelatankSystemLogin->setObjectName(QString::fromUtf8("MelatankSystemLogin"));
        MelatankSystemLogin->resize(1062, 638);

        retranslateUi(MelatankSystemLogin);

        QMetaObject::connectSlotsByName(MelatankSystemLogin);
    } // setupUi

    void retranslateUi(QDialog *MelatankSystemLogin)
    {
        MelatankSystemLogin->setWindowTitle(QApplication::translate("MelatankSystemLogin", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MelatankSystemLogin: public Ui_MelatankSystemLogin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MELATANKSYSTEMLOGIN_H
