#include "melatanksystemlogin.h"
#include "ui_melatanksystemlogin.h"

MelatankSystemLogin::MelatankSystemLogin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MelatankSystemLogin)
{
    ui->setupUi(this);
}

MelatankSystemLogin::~MelatankSystemLogin()
{
    delete ui;
}
