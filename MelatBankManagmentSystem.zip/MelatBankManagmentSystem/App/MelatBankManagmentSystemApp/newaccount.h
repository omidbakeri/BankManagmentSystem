#ifndef NEWACCOUNT_H
#define NEWACCOUNT_H

#include <QDialog>

namespace Ui {
class NewAccount;
}

class NewAccount : public QDialog
{
    Q_OBJECT

public:
    explicit NewAccount(QWidget *parent = nullptr);
    ~NewAccount();

private slots:
    void on_confirmationPushButton_clicked();

    void on_nameLineEdit_cursorPositionChanged(int arg1, int arg2);

    void on_confirmationPushButton_pressed();

    void on_confirmationPushButton_2_clicked();

    void on_closePushButton_clicked();

    void on_backPushButton_clicked();

private:
    Ui::NewAccount *ui;
};

#endif // NEWACCOUNT_H
