#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "loginemployeeform.h"
#include "QPushButton"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)


{
    ui->setupUi(this);
    connect(ui->pushButtonClose , SIGNAL(clicked()) , this , SLOT(close()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButtonLogin_clicked()
{

    LoginEmployeeForm *loginEmployee_Form = new LoginEmployeeForm;
    this->close();
    loginEmployee_Form->show();
}
