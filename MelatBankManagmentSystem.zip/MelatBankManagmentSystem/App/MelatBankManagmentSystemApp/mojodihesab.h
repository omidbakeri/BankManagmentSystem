#ifndef MOJODIHESAB_H
#define MOJODIHESAB_H

#include <QDialog>

namespace Ui {
class MojodiHesab;
}

class MojodiHesab : public QDialog
{
    Q_OBJECT

public:
    explicit MojodiHesab(QWidget *parent = nullptr);
    ~MojodiHesab();

private slots:
    void on_accountNumberRadioButton_clicked();

    void on_NLNRadioButton_clicked();

    void on_CartNimberRadioButton_clicked();

    void on_accountNumberRadioButton_pressed();

    void on_lastnameShoMPushButton_clicked();

    void on_CheckPushButton_clicked();

    void on_ShowMojodiCheckPushButton_clicked();

    void on_accountNumberShowMojodiCheckPushButton_clicked();

    void on_LastNamePushButton_clicked();

    void on_accountNumberPushButton_clicked();

    void on_pushButton_clicked();

private:
    Ui::MojodiHesab *ui;
};

#endif // MOJODIHESAB_H
