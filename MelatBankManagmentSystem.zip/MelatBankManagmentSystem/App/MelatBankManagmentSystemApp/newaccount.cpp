#include "newaccount.h"
#include "ui_newaccount.h"
#include "operationmelatbanksystem.h"
#include "QLineEdit"
#include "QMessageBox"

NewAccount::NewAccount(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::NewAccount)
{
    ui->setupUi(this);
}

NewAccount::~NewAccount()
{
    delete ui;
}


void NewAccount::on_closePushButton_clicked()
{
    this->close();
}


void NewAccount::on_backPushButton_clicked()
{
    this->hide();
    OperationMelatBankSystem *operatorPage = new OperationMelatBankSystem;
    operatorPage->show();
}


void NewAccount::on_confirmationPushButton_clicked()
{
    bool name;
    bool lastname;
    bool nationalcode;
    bool day;
    bool month;
    bool year;
    bool fathername;
    bool accountNumber;
    bool accountType;
    bool shamereKart;
    bool mojodi;

   // QMessageBox *Message = new QMessageBox;


    if(ui->nameLineEdit->text()=="")
    {
        name=false;
        QMessageBox::critical(this , "خطا" , "پر کردن فیلد نام الزامی است");

    }
    if(ui->nameLineEdit->text()!="")
    {
        name=true;
    }



    if(ui->lstnameLineEdit->text()=="")
    {
        lastname=false;
        QMessageBox::critical(this , "خطا" , "پر کردن فیلد نام خانوادگی الزامی است");
    }
    if(ui->lstnameLineEdit->text()!="")
    {
        lastname=true;
    }


    if(ui->nationalcodeLineEdit->text()=="")
    {
        nationalcode=false;
        QMessageBox::critical(this , "خطا" , "پر کردن فیلد کد ملی الزامی می باشد");
    }
    if(ui->nationalcodeLineEdit->text()!="")
    {
        nationalcode=true;

    }

    if(ui->dayLineEdit->text()=="")
    {
        day=false;
        QMessageBox::critical(this , "خطا" , "پر کردن فیلد روز تولد الزامی است");
    }
    if(ui->dayLineEdit->text()!="")
    {
        day=true;
    }


    if(ui->monthLineEdit->text()=="")
    {
        month=false;
        QMessageBox::critical(this , "خطا" , "پر کردن فیلد ماه تولد الزامی است");
    }
    if(ui->monthLineEdit->text()!="")
    {
        month=true;
    }



    if(ui->yearLineEdit->text()=="")
    {
        year=false;
        QMessageBox::critical(this , "خطا" , "پر کردن فیلد سال تولد الزامی است");
    }
    if(ui->yearLineEdit->text()!="")
    {
        year=true;
    }



    if(ui->fathernameLineEdit->text()=="")
    {
        fathername=false;
        QMessageBox::critical(this , "خطا" , "پر کردن فیلد نام پدر الزامی است");
    }
    if(ui->fathernameLineEdit->text()!="")
    {
        fathername=true;
    }




    if(ui->numberofAccountLineEdit->text()=="")
    {
        accountNumber=false;
        QMessageBox::critical(this , "خطا" , "پر کردن فیلد شماره حساب الزامی است");
    }
    if(ui->nameLineEdit->text()!="")
    {
        accountNumber=true;
    }




    if(ui->jariRadioButton->isChecked()==false && ui->GhRadioButton->isChecked()==false)
    {
        accountType=false;
        QMessageBox::critical(this , "خطا" , "نوع حسابتان را مشخص کنید");
    }
    if(ui->jariRadioButton->isChecked()==true || ui->GhRadioButton->isChecked()==true)
    {
        accountType=true;

        //QMessageBox::critical(this , "خطا" , "نوع حسابتان را مشخص کنید");
    }



    if(ui->shomareCartLineEdit->text()=="")
    {
        shamereKart=false;
        QMessageBox::critical(this , "خطا" , "پر کردن فیلد شماره کارت الزامی است");
    }
    if(ui->shomareCartLineEdit->text()!="")
    {
        shamereKart=true;
    }



    if(ui->mojodiLineEdit->text()=="")
    {
        mojodi=false;
        QMessageBox::critical(this , "خطا" , "پر کردن فیلد موجودی حساب الزامی است");
    }
    if(ui->mojodiLineEdit->text()!="")
    {
        mojodi=true;
    }


    if(ui->dayLineEdit->text()<1  || ui->dayLineEdit->text()>31)
    {
        day=false;
        QMessageBox::critical(this , "1خطا" , "تاریخ نامعتبر");
    }
    if(ui->dayLineEdit->text()>=1  && ui->dayLineEdit->text()<=31)
    {
        day=true;

    }



    if(ui->monthLineEdit->text()<1  || ui->monthLineEdit->text()>12)
    {
        month=false;
        QMessageBox::critical(this , "2خطا" , "تاریخ نامعتبر");

    }

    if(ui->monthLineEdit->text()>1  && ui->monthLineEdit->text()<=12)
    {
        month=true;

    }



    if(ui->yearLineEdit->text()>1400)
    {
        year=false;
        QMessageBox::critical(this , "خطا" , "تاریخ نامعتبر3");
    }
    if(ui->yearLineEdit->text()>=1386)
    {
        year=false;
        QMessageBox::critical(this , "خطا" , "تاریخ نامعتبر ، امکان ایجاد حساب جدید برای شما نیست");
    }
    if(ui->yearLineEdit->text()<1386)
    {
        year=true;

    }


    if(ui->dayLineEdit->text().length()!=2)
    {
        day=false;
        QMessageBox::critical(this , "خطا" , "تاریخ نامعتبر ، روز دو رقم وارد شود");

    }
    if(ui->dayLineEdit->text().length()==2)
    {
        day=true;
    }




    if(ui->monthLineEdit->text().length()!=2)
    {
        month=false;
        QMessageBox::critical(this , "خطا" , "تاریخ نامعتبر ، ماه 2 رقم وارد شود ");
    }
    if(ui->monthLineEdit->text().length()==2)
    {
        month=true;
    }




    if(ui->yearLineEdit->text().length()!=4)
    {
        year=false;
        QMessageBox::critical(this , "خطا" , "تاریخ نامعتبر ، سال 4 رقم وارد شود");


    }
    if(ui->yearLineEdit->text().length()==4)
    {
        year=true;

    }





    if(ui->numberofAccountLineEdit->text().length()!=10)
    {
        accountNumber=false;
        QMessageBox::critical(this , "خطا" , "شماره حساب نامعتبر");


    }
    if(ui->numberofAccountLineEdit->text().length()==10)
    {
        accountNumber=true;
        //QMessageBox::critical(this , "شماره حساب نامعتبر" , "خطا");

    }

//    if(ui->jariRadioButton->text()==""  || ui->GhRadioButton->text()=="")
//    {
//        jari=false;
//        gharzalhasane=true;

//    }



    if(ui->shomareCartLineEdit->text().length()!=16)
    {
        accountNumber=false;
        QMessageBox::critical(this , "خطا" , "شماره کارت نامعتبر");

    }
    if(ui->shomareCartLineEdit->text().length()==16)
    {
        accountNumber=true;


    }



//    if(ui->mojodiLineEdit->text()<5000000)
//    {
//        mojodi=false;
//         QMessageBox::critical(this , "خطا" , "موجودی شما کمتر از حداقل مصوبه بانک است ، سیستم این موجودی را نمی پذیرد");
//    }
//    if(ui->mojodiLineEdit->text()>5000000)
//    {
//        mojodi=true;
//    }



    if(name==true  && lastname==true  && nationalcode==true  && day==true  && month==true  && year==true  && fathername==true   &&  accountNumber==true &&    accountType    && shamereKart==true  && mojodi==true)
    {
        this->hide();
        QMessageBox::critical(this , "تایید" , "تبریک ، حساب جدید شما با موفقیت ساخته شد");
        OperationMelatBankSystem *op = new OperationMelatBankSystem;
        op->show();
    }

}

