#define EMPLOYEELOGINFORM_H
#ifndef EMPLOYEELOGINFORM_H
#include "employeeloginform.h"
#include "ui_employeeloginform.h"

namespace Ui {
class EmployeeLoginForm;
}

class EmployeeLoginForm : public QDialog
{
    Q_OBJECT

public:
    explicit EmployeeLoginForm(QWidget *parent = nullptr);
    ~EmployeeLoginForm();

private:
    Ui::EmployeeLoginForm *ui;
};

#endif // EMPLOYEELOGINFORM_H
