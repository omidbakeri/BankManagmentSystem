#include "employeeloginform.h"
#include "ui_employeeloginform.h"
#ifndef EMPLOYEELOGINFORM_H
#define EMPLOYEELOGINFORM_H

EmployeeLoginForm::EmployeeLoginForm(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EmployeeLoginForm)
{
    ui->setupUi(this);
}

EmployeeLoginForm::~EmployeeLoginForm()
{
    delete ui;
}
#endif
