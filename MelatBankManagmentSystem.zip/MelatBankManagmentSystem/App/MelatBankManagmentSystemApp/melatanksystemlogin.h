#ifndef MELATANKSYSTEMLOGIN_H
#define MELATANKSYSTEMLOGIN_H

#include <QDialog>

namespace Ui {
class MelatankSystemLogin;
}

class MelatankSystemLogin : public QDialog
{
    Q_OBJECT

public:
    explicit MelatankSystemLogin(QWidget *parent = nullptr);
    ~MelatankSystemLogin();

private:
    Ui::MelatankSystemLogin *ui;
};

#endif // MELATANKSYSTEMLOGIN_H
