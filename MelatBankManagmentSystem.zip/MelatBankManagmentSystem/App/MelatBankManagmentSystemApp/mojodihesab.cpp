#include "mojodihesab.h"
#include "ui_mojodihesab.h"
#include "QMessageBox"
#include "newaccount.h"
#include "QLineEdit"
#include "QPushButton"
#include "operationmelatbanksystem.h"

MojodiHesab::MojodiHesab(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MojodiHesab)
{
    ui->setupUi(this);
}

MojodiHesab::~MojodiHesab()
{
    delete ui;
}

//void MojodiHesab::on_accountNumberRadioButton_clicked()
//{

//}


//void MojodiHesab::on_NLNRadioButton_clicked()
//{
//    ui->showMojodiLabel->text()="نام خانوادگی خود را وارد نمایید";
//}



//void MojodiHesab::on_CartNimberRadioButton_clicked()
//{
//     ui->showMojodiLabel->text()="شماره کارت خود را وارد نمایید";
//}


//void MojodiHesab::on_accountNumberRadioButton_pressed()
//{

//    connect(ui->accountNumberRadioButton , SIGNAL(pressed()) , this  , SLOT(show()));
//    ui->showMojodiLabel->text()="شماره حسابتان را وارد نمایید";
//}


//void MojodiHesab::on_lastnameShoMPushButton_clicked()
//{
//    bool lastnamepushChek ;

//    if(ui->lastnameShoMPushButton->text()=="")
//    {
//        lastnamepushChek=false;
//      //QMessageBox::critical(this , "خطا" , "لطفا نام خانوادگی خود را وارد نمایید");
//    }
//    if(ui->lastnameShoMPushButton->text()!="")
//    {
//        lastnamepushChek=true;
//        //QMessageBox::critical(this , "لطفا نام خانوادگی خود را وارد نمایید" , "خطا");
//    }


//    if(lastnamepushChek==true)
//    {
//        QMessageBox::critical(this , "خطا" , "عملیات نامعتبر");

//    }

//}


//void MojodiHesab::on_CheckPushButton_clicked()
//{
//    bool accountNumberpushCheck;

//    if(ui->NLNRadioButton->text()=="")
//    {
//        accountNumberpushCheck=false;
//        QMessageBox::critical(this , "خطا" , "لطفا شماره حساب خود را وارد نمایید");

//    }

//    if(ui->NLNRadioButton->text()!="")
//    {
//        accountNumberpushCheck=true;
//        //QMessageBox::critical(this , "خطا" , "لطفا شماره حساب خود را وارد نمایید");
//    }

//    if(ui->NLNRadioButton->text().length()!=10)
//    {
//        accountNumberpushCheck=false;
//        QMessageBox::critical(this , "خطا" , "شماره حساب باید 10 رقم باشد");

//    }
//    if(ui->NLNRadioButton->text().length()==10)
//    {
//        accountNumberpushCheck=true;
//    }
//    if(accountNumberpushCheck==true)
//    {
//        QMessageBox::critical(this , "خطا" , "عملیات نامعتبر");

//    }

//}


//void MojodiHesab::on_ShowMojodiCheckPushButton_clicked()
//{
//    if(ui->)
//}

    bool accountNumberflag;
    bool lastNameflag;
//void MojodiHesab::on_accountNumberShowMojodiCheckPushButton_clicked()
//{


//    if(ui->accountNumbershowMojodiLineEdit->text()=="")
//    {
//        accountNumberflag=false;
//        QMessageBox::critical(this , "خطا" , "لطفا شماره حساب خود را وارد نمایید");
//    }
//    if(ui->accountNumbershowMojodiLineEdit->text()!="")
//    {
//        accountNumberflag=true;
//    }
//    if(ui->accountNumbershowMojodiLineEdit->text().length()!=10)
//    {
//        accountNumberflag=false;
//        QMessageBox::critical(this , "خطا" , "شماره حساب باید 10 رقم داشته باشد");
//    }

//    if(accountNumberflag==true)
//    {
//        QMessageBox::critical(this , "خطا" , "حسابی با این شماره حساب وجود ندارد");
//    }

//}


void MojodiHesab::on_LastNamePushButton_clicked()
{
    if(ui->lastnameShowMLineEdit->text()=="")
    {
        lastNameflag-=false;
        QMessageBox::critical(this , "خطا" , "لطفا نام خانوادگی خود را وارد نمایید");
    }
    if(ui->lastnameShowMLineEdit->text()!="")
    {
        lastNameflag=true;
    }

    if(lastNameflag==true)
    {
        QMessageBox::critical(this , "خطا" , "حسابی با این نام خانوادگی وجود ندارد");
    }
}


void MojodiHesab::on_accountNumberPushButton_clicked()
{
    if(ui->accountNumbershowMojodiLineEdit->text()=="")
    {
        accountNumberflag=false;
        QMessageBox::critical(this , "خطا" , "لطفا شماره حساب خود را وارد نمایید");
    }
    if(ui->accountNumbershowMojodiLineEdit->text()!="")
    {
        accountNumberflag=true;
    }
    if(ui->accountNumbershowMojodiLineEdit->text().length()!=10)
    {
        accountNumberflag=false;
        QMessageBox::critical(this , "خطا" , "شماره حساب باید 10 رقم داشته باشد");
    }

    if(ui->accountNumbershowMojodiLineEdit->text().length()==10)
    {
        accountNumberflag=true;
        //QMessageBox::critical(this , "خطا" , "شماره حساب باید 10 رقم داشته باشد");
    }



    if(accountNumberflag==true)
    {
        QMessageBox::critical(this , "خطا" , "حسابی با این شماره حساب وجود ندارد");
    }
}


void MojodiHesab::on_pushButton_clicked()
{
    this->hide();
    OperationMelatBankSystem *operators  =  new OperationMelatBankSystem;
    operators->show();

}

