#include "variz.h"
#include "ui_variz.h"
#include "QMessageBox"

Variz::Variz(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Variz)
{
    ui->setupUi(this);
}

Variz::~Variz()
{
    delete ui;
}

void Variz::on_pushButton_clicked()
{

}


void Variz::on_CheckVarizPushButton_clicked()
{

    bool fcn;
    bool scn;

    // first cart number property code
    if(ui->firstCartNumber->text()=="")
    {
        fcn=false;
        QMessageBox::critical(this , "خطا" , "شماره کارت مبدا را وارد نمایید");
    }
    if(ui->firstCartNumber->text()!="")
    {
        fcn=true;
       // QMessageBox::critical(this , "خطا" , "شماره کارت مبدا را وارد نمایید");
    }
    if(ui->firstCartNumber->text().length()!=16)
    {
        fcn=false;
        QMessageBox::critical(this , "خطا" , "شماره کارت مبدا درست وارد نشده است");
    }

    if(ui->SecondCartNumber->text().length()==16)
    {
        fcn=true;
        //QMessageBox::critical(this , "خطا" , "شماره کارت مبدا درست وارد نشده است");
    }






    // second cart number property code
    if(ui->SecondCartNumber->text()=="")
    {
        scn=false;
        QMessageBox::critical(this , "خطا" , "شماره کارت مقصد را وارد نمایید");
    }
    if(ui->SecondCartNumber->text()!="")
    {
        scn=true;

    }
    if(ui->SecondCartNumber->text().length()!=16)
    {
        scn=false;
        QMessageBox::critical(this , "خطا" , "شماره کارت مقصد درست وارد نشده است");
    }

    if(ui->SecondCartNumber->text().length()==16)
    {
        scn=true;

    }

    if(fcn==true  && scn==true)
    {
        QMessageBox::critical(this , "خطا" , "عملیات نامعتبر ، شماره کارت میدا موجود نیست");
    }













}

