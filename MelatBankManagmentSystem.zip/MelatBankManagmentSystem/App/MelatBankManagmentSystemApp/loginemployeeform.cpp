#include "loginemployeeform.h"
#include "ui_loginemployeeform.h"
#include "operationmelatbanksystem.h"
#include "QPushButton"
#include "mainwindow.h"
#include "QMessageBox"
#include "QLineEdit"
#include "QLabel"
#include "QMessageBox"

LoginEmployeeForm::LoginEmployeeForm(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginEmployeeForm)
{
    ui->setupUi(this);
    connect(ui->pushButton , SIGNAL(clicked()) , this , SLOT(close()));

}

LoginEmployeeForm::~LoginEmployeeForm()
{
    delete ui;
}

void LoginEmployeeForm::on_pushButtonBack_clicked()
{
    MainWindow *mainmanagmentmelatBankSystem_Welcomepage = new MainWindow;
    mainmanagmentmelatBankSystem_Welcomepage->show();
    this->hide();

}

void LoginEmployeeForm::on_pushButtonLogin_clicked()
{
    if(ui->usernameLine->text()==""  || ui->passwordnameLine->text()=="")
    {
        QMessageBox::critical(this , "information" , "لطفا تمام فیلد ها را پر کنید");
    }
    if(ui->passwordnameLine->text().length()!=10)
    {
        QMessageBox::critical(this , "information"  , "رمز عبور شما باید 10 رقم باشد");

    }

    if(ui->usernameLine->text()!="" && ui->passwordnameLine->text()!="" && ui->passwordnameLine->text().length()==10)
    {
            OperationMelatBankSystem *operationMelatBank = new OperationMelatBankSystem;
            this->close();
            operationMelatBank->show();
    }


}

//void LoginEmployeeForm::on_usernameLine_cursorPositionChanged(int arg1, int arg2)
//{
//    if(ui->usernameLine->text()=="" || ui->passwordnameLine->text()=="")
//    {
//        QMessageBox::critical(this , "My Title" , "please fill all field");
//    }
//}
