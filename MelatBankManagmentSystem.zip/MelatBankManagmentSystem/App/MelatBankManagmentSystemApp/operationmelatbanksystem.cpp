#include "operationmelatbanksystem.h"
#include "ui_operationmelatbanksystem.h"
#include "newaccount.h"
#include "mojodihesab.h"
#include "variz.h"
#include "loginemployeeform.h"



OperationMelatBankSystem::OperationMelatBankSystem(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OperationMelatBankSystem)
{
    ui->setupUi(this);
}

OperationMelatBankSystem::~OperationMelatBankSystem()
{
    delete ui;
}

void OperationMelatBankSystem::on_newAccount_pushButton_clicked()
{
    NewAccount *newAccount_MelatBankSystem = new NewAccount;
    newAccount_MelatBankSystem->show();
    this->hide();
}

void OperationMelatBankSystem::on_InventorAccount_pushButton_clicked()
{
    this->close();
    MojodiHesab *mojodidarHesab = new MojodiHesab;
    mojodidarHesab->show();
}


//void OperationMelatBankSystem::on_DepositToAccount_pushButton_clicked()
//{
//    this->hide();

//}


void OperationMelatBankSystem::on_DepositToAccount_pushButton_clicked()
{
    this->hide();
    Variz *OperationVarizToAccountSystem = new Variz;
    OperationVarizToAccountSystem->show();

}


void OperationMelatBankSystem::on_Back_pushButton_clicked()
{
    this->hide();
    LoginEmployeeForm *loginPage  =  new LoginEmployeeForm;
    loginPage->show();

}


void OperationMelatBankSystem::on_Close_pushButton_clicked()
{
     this->close();
}

