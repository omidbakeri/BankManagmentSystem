#ifndef LOGINEMPLOYEEFORM_H
#define LOGINEMPLOYEEFORM_H
#include "QLineEdit"
#include <QDialog>

namespace Ui {
class LoginEmployeeForm;
}

class LoginEmployeeForm : public QDialog
{
    Q_OBJECT

public:
    explicit LoginEmployeeForm(QWidget *parent = nullptr);
    ~LoginEmployeeForm();

private slots:
    void on_pushButtonBack_clicked();

    void on_pushButtonLogin_clicked();

    void on_usernameLine_cursorPositionChanged(int arg1, int arg2);

private:
    Ui::LoginEmployeeForm *ui;
};

#endif // LOGINEMPLOYEEFORM_H
