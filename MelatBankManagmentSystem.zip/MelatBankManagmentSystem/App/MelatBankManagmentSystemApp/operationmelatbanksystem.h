#ifndef OPERATIONMELATBANKSYSTEM_H
#define OPERATIONMELATBANKSYSTEM_H

#include <QDialog>

namespace Ui {
class OperationMelatBankSystem;
}

class OperationMelatBankSystem : public QDialog
{
    Q_OBJECT

public:
    explicit OperationMelatBankSystem(QWidget *parent = nullptr);
    ~OperationMelatBankSystem();

private slots:
    void on_newAccount_pushButton_clicked();

    void on_InventorAccount_pushButton_clicked();

    void on_DepositToAccount_pushButton_clicked();

    void on_Back_pushButton_clicked();

    void on_Close_pushButton_clicked();

private:
    Ui::OperationMelatBankSystem *ui;
};

#endif // OPERATIONMELATBANKSYSTEM_H
