#ifndef VARIZ_H
#define VARIZ_H

#include <QDialog>

namespace Ui {
class Variz;
}

class Variz : public QDialog
{
    Q_OBJECT

public:
    explicit Variz(QWidget *parent = nullptr);
    ~Variz();

private slots:
    void on_pushButton_clicked();

    void on_CheckVarizPushButton_clicked();

private:
    Ui::Variz *ui;
};

#endif // VARIZ_H
