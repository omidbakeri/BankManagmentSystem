/********************************************************************************
** Form generated from reading UI file 'mojodihesab.ui'
**
** Created by: Qt User Interface Compiler version 5.12.11
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MOJODIHESAB_H
#define UI_MOJODIHESAB_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_MojodiHesab
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QRadioButton *accountNumberRadioButton;
    QRadioButton *NLNRadioButton;
    QLabel *showMojodiLabel;
    QLineEdit *accountNumbershowMojodiLineEdit;
    QPushButton *accountNumberPushButton;
    QLabel *labelSet;
    QLabel *lastnameShwMLabel;
    QLineEdit *lastnameShowMLineEdit;
    QPushButton *LastNamePushButton;
    QLabel *label_7;
    QPushButton *pushButton;

    void setupUi(QDialog *MojodiHesab)
    {
        if (MojodiHesab->objectName().isEmpty())
            MojodiHesab->setObjectName(QString::fromUtf8("MojodiHesab"));
        MojodiHesab->resize(1062, 638);
        MojodiHesab->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);"));
        label = new QLabel(MojodiHesab);
        label->setObjectName(QString::fromUtf8("label"));
        label->setEnabled(true);
        label->setGeometry(QRect(10, 10, 1031, 161));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_2 = new QLabel(MojodiHesab);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setEnabled(true);
        label_2->setGeometry(QRect(10, 180, 1031, 441));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_3 = new QLabel(MojodiHesab);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(380, 40, 327, 110));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/pref2/bank melat.jpg")));
        label_3->setScaledContents(true);
        label_4 = new QLabel(MojodiHesab);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 200, 991, 61));
        label_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 0, 0);"));
        label_5 = new QLabel(MojodiHesab);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 270, 991, 341));
        label_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_6 = new QLabel(MojodiHesab);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(716, 390, 281, 41));
        label_6->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        accountNumberRadioButton = new QRadioButton(MojodiHesab);
        accountNumberRadioButton->setObjectName(QString::fromUtf8("accountNumberRadioButton"));
        accountNumberRadioButton->setGeometry(QRect(620, 340, 101, 31));
        accountNumberRadioButton->setCursor(QCursor(Qt::PointingHandCursor));
        accountNumberRadioButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        NLNRadioButton = new QRadioButton(MojodiHesab);
        NLNRadioButton->setObjectName(QString::fromUtf8("NLNRadioButton"));
        NLNRadioButton->setGeometry(QRect(620, 460, 101, 31));
        NLNRadioButton->setCursor(QCursor(Qt::PointingHandCursor));
        NLNRadioButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        showMojodiLabel = new QLabel(MojodiHesab);
        showMojodiLabel->setObjectName(QString::fromUtf8("showMojodiLabel"));
        showMojodiLabel->setEnabled(true);
        showMojodiLabel->setGeometry(QRect(290, 400, 221, 31));
        showMojodiLabel->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        accountNumbershowMojodiLineEdit = new QLineEdit(MojodiHesab);
        accountNumbershowMojodiLineEdit->setObjectName(QString::fromUtf8("accountNumbershowMojodiLineEdit"));
        accountNumbershowMojodiLineEdit->setEnabled(true);
        accountNumbershowMojodiLineEdit->setGeometry(QRect(80, 400, 201, 31));
        accountNumbershowMojodiLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        accountNumberPushButton = new QPushButton(MojodiHesab);
        accountNumberPushButton->setObjectName(QString::fromUtf8("accountNumberPushButton"));
        accountNumberPushButton->setEnabled(true);
        accountNumberPushButton->setGeometry(QRect(80, 450, 121, 41));
        accountNumberPushButton->setCursor(QCursor(Qt::PointingHandCursor));
        accountNumberPushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 170, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        labelSet = new QLabel(MojodiHesab);
        labelSet->setObjectName(QString::fromUtf8("labelSet"));
        labelSet->setGeometry(QRect(60, 340, 541, 191));
        labelSet->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lastnameShwMLabel = new QLabel(MojodiHesab);
        lastnameShwMLabel->setObjectName(QString::fromUtf8("lastnameShwMLabel"));
        lastnameShwMLabel->setEnabled(true);
        lastnameShwMLabel->setGeometry(QRect(290, 400, 221, 31));
        lastnameShwMLabel->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        lastnameShowMLineEdit = new QLineEdit(MojodiHesab);
        lastnameShowMLineEdit->setObjectName(QString::fromUtf8("lastnameShowMLineEdit"));
        lastnameShowMLineEdit->setEnabled(true);
        lastnameShowMLineEdit->setGeometry(QRect(80, 400, 201, 31));
        lastnameShowMLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        LastNamePushButton = new QPushButton(MojodiHesab);
        LastNamePushButton->setObjectName(QString::fromUtf8("LastNamePushButton"));
        LastNamePushButton->setEnabled(true);
        LastNamePushButton->setGeometry(QRect(80, 450, 121, 41));
        LastNamePushButton->setCursor(QCursor(Qt::PointingHandCursor));
        LastNamePushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 170, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_7 = new QLabel(MojodiHesab);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(60, 330, 521, 221));
        label_7->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton = new QPushButton(MojodiHesab);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(830, 520, 141, 51));
        pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 170, 0);\n"
"font: 12pt \"MS Shell Dlg 2\";"));

        retranslateUi(MojodiHesab);
        QObject::connect(accountNumberRadioButton, SIGNAL(pressed()), labelSet, SLOT(hide()));
        QObject::connect(NLNRadioButton, SIGNAL(pressed()), label_7, SLOT(hide()));
        QObject::connect(accountNumberRadioButton, SIGNAL(pressed()), label_7, SLOT(hide()));
        QObject::connect(accountNumberRadioButton, SIGNAL(pressed()), lastnameShwMLabel, SLOT(hide()));
        QObject::connect(accountNumberRadioButton, SIGNAL(pressed()), lastnameShowMLineEdit, SLOT(hide()));
        QObject::connect(accountNumberRadioButton, SIGNAL(pressed()), LastNamePushButton, SLOT(hide()));
        QObject::connect(NLNRadioButton, SIGNAL(pressed()), labelSet, SLOT(hide()));
        QObject::connect(NLNRadioButton, SIGNAL(pressed()), lastnameShwMLabel, SLOT(show()));
        QObject::connect(NLNRadioButton, SIGNAL(pressed()), lastnameShowMLineEdit, SLOT(show()));
        QObject::connect(NLNRadioButton, SIGNAL(pressed()), LastNamePushButton, SLOT(show()));

        QMetaObject::connectSlotsByName(MojodiHesab);
    } // setupUi

    void retranslateUi(QDialog *MojodiHesab)
    {
        MojodiHesab->setWindowTitle(QApplication::translate("MojodiHesab", "Dialog", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        label_3->setText(QString());
        label_4->setText(QApplication::translate("MojodiHesab", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt;\">\331\205\331\210\330\254\331\210\330\257\333\214 \330\255\330\263\330\247\330\250 \330\264\331\205\330\247 </span></p></body></html>", nullptr));
        label_5->setText(QString());
        label_6->setText(QApplication::translate("MojodiHesab", "<html><head/><body><p align=\"center\"><span style=\" font-size:11pt; font-weight:600; font-style:italic; color:#ff0000;\">\330\250\330\261\330\261\330\263\333\214 \331\205\331\210\330\254\331\210\330\257\333\214 \330\255\330\263\330\247\330\250 \330\250\330\261 \330\247\330\263\330\247\330\263</span></p></body></html>", nullptr));
        accountNumberRadioButton->setText(QApplication::translate("MojodiHesab", "\330\264\331\205\330\247\330\261\331\207 \330\255\330\263\330\247\330\250", nullptr));
        NLNRadioButton->setText(QApplication::translate("MojodiHesab", "\331\206\330\247\331\205 \330\256\330\247\331\206\331\210\330\247\330\257\332\257\333\214", nullptr));
        showMojodiLabel->setText(QApplication::translate("MojodiHesab", "\330\264\331\205\330\247\330\261\331\207 \330\255\330\263\330\247\330\250 \330\256\331\210\330\257 \330\261\330\247 \331\210\330\247\330\261\330\257 \331\206\331\205\330\247\333\214\333\214\330\257", nullptr));
        accountNumberPushButton->setText(QApplication::translate("MojodiHesab", "\330\250\330\261\330\261\330\263\333\214", nullptr));
        labelSet->setText(QString());
        lastnameShwMLabel->setText(QApplication::translate("MojodiHesab", "\331\206\330\247\331\205 \330\256\330\247\331\206\331\210\330\247\330\257\332\257\333\214 \330\256\331\210\330\257 \330\261\330\247 \331\210\330\247\330\261\330\257 \331\206\331\205\330\247\333\214\333\214\330\257", nullptr));
        LastNamePushButton->setText(QApplication::translate("MojodiHesab", "\330\250\330\261\330\261\330\263\333\214", nullptr));
        label_7->setText(QString());
        pushButton->setText(QApplication::translate("MojodiHesab", "\330\250\330\261\332\257\330\264\330\252", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MojodiHesab: public Ui_MojodiHesab {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MOJODIHESAB_H
