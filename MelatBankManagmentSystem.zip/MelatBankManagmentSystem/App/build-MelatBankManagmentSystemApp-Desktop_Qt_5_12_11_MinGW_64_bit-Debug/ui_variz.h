/********************************************************************************
** Form generated from reading UI file 'variz.ui'
**
** Created by: Qt User Interface Compiler version 5.12.11
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VARIZ_H
#define UI_VARIZ_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Variz
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *firstCartNumber;
    QLineEdit *SecondCartNumber;
    QPushButton *CheckVarizPushButton;

    void setupUi(QDialog *Variz)
    {
        if (Variz->objectName().isEmpty())
            Variz->setObjectName(QString::fromUtf8("Variz"));
        Variz->resize(1062, 638);
        Variz->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);"));
        label = new QLabel(Variz);
        label->setObjectName(QString::fromUtf8("label"));
        label->setEnabled(true);
        label->setGeometry(QRect(10, 20, 1031, 161));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_2 = new QLabel(Variz);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setEnabled(true);
        label_2->setGeometry(QRect(10, 190, 1031, 431));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_3 = new QLabel(Variz);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(360, 50, 327, 110));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/pref2/bank melat.jpg")));
        label_3->setScaledContents(true);
        label_4 = new QLabel(Variz);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 200, 991, 61));
        label_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 0, 0);"));
        label_5 = new QLabel(Variz);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 270, 991, 341));
        label_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_6 = new QLabel(Variz);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(740, 310, 251, 61));
        label_7 = new QLabel(Variz);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(740, 380, 251, 61));
        firstCartNumber = new QLineEdit(Variz);
        firstCartNumber->setObjectName(QString::fromUtf8("firstCartNumber"));
        firstCartNumber->setGeometry(QRect(190, 310, 541, 61));
        firstCartNumber->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 85, 255);\n"
"font: 16pt \"MS Shell Dlg 2\";"));
        SecondCartNumber = new QLineEdit(Variz);
        SecondCartNumber->setObjectName(QString::fromUtf8("SecondCartNumber"));
        SecondCartNumber->setGeometry(QRect(190, 380, 541, 61));
        SecondCartNumber->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 85, 255);\n"
"font: 16pt \"MS Shell Dlg 2\";"));
        CheckVarizPushButton = new QPushButton(Variz);
        CheckVarizPushButton->setObjectName(QString::fromUtf8("CheckVarizPushButton"));
        CheckVarizPushButton->setGeometry(QRect(190, 460, 181, 61));
        CheckVarizPushButton->setStyleSheet(QString::fromUtf8("font: 14pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 170, 255);"));

        retranslateUi(Variz);

        QMetaObject::connectSlotsByName(Variz);
    } // setupUi

    void retranslateUi(QDialog *Variz)
    {
        Variz->setWindowTitle(QApplication::translate("Variz", "Dialog", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        label_3->setText(QString());
        label_4->setText(QApplication::translate("Variz", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt;\">\330\271\331\205\331\204\333\214\330\247\330\252 \331\210\330\247\330\261\333\214\330\262</span></p></body></html>", nullptr));
        label_5->setText(QString());
        label_6->setText(QApplication::translate("Variz", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; color:#ffffff;\">\330\264\331\205\330\247\330\261\331\207 \332\251\330\247\330\261\330\252 \331\205\330\250\330\257\330\247</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("Variz", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; color:#ffffff;\">\330\264\331\205\330\247\330\261\331\207 \332\251\330\247\330\261\330\252 \331\205\331\202\330\265\330\257</span></p></body></html>", nullptr));
        CheckVarizPushButton->setText(QApplication::translate("Variz", "\330\250\330\261\330\261\330\263\333\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Variz: public Ui_Variz {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VARIZ_H
