/********************************************************************************
** Form generated from reading UI file 'operationmelatbanksystem.ui'
**
** Created by: Qt User Interface Compiler version 5.12.11
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OPERATIONMELATBANKSYSTEM_H
#define UI_OPERATIONMELATBANKSYSTEM_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_OperationMelatBankSystem
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *newAccount_pushButton;
    QPushButton *DepositToAccount_pushButton;
    QPushButton *harvest_pushButton;
    QPushButton *InventorAccount_pushButton;
    QPushButton *showInformation_pushButton;
    QPushButton *DeleteAccount_pushButton;
    QPushButton *EditAccount_pushButton;
    QPushButton *Close_pushButton;
    QPushButton *Back_pushButton;
    QPushButton *EmployeeInformation_pushButton;
    QPushButton *programmer_pushButton;

    void setupUi(QDialog *OperationMelatBankSystem)
    {
        if (OperationMelatBankSystem->objectName().isEmpty())
            OperationMelatBankSystem->setObjectName(QString::fromUtf8("OperationMelatBankSystem"));
        OperationMelatBankSystem->resize(1057, 636);
        OperationMelatBankSystem->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);"));
        label = new QLabel(OperationMelatBankSystem);
        label->setObjectName(QString::fromUtf8("label"));
        label->setEnabled(true);
        label->setGeometry(QRect(20, 20, 1021, 171));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_2 = new QLabel(OperationMelatBankSystem);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setEnabled(true);
        label_2->setGeometry(QRect(20, 200, 1021, 421));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_3 = new QLabel(OperationMelatBankSystem);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(360, 50, 361, 111));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/pref2/bank melat.jpg")));
        label_3->setScaledContents(true);
        label_4 = new QLabel(OperationMelatBankSystem);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 210, 1001, 51));
        label_4->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"color: rgb(255, 255, 255);"));
        newAccount_pushButton = new QPushButton(OperationMelatBankSystem);
        newAccount_pushButton->setObjectName(QString::fromUtf8("newAccount_pushButton"));
        newAccount_pushButton->setGeometry(QRect(710, 270, 321, 71));
        QFont font;
        font.setPointSize(14);
        newAccount_pushButton->setFont(font);
        newAccount_pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        newAccount_pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 170, 255);"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/new/prefix1/new account.png"), QSize(), QIcon::Normal, QIcon::Off);
        newAccount_pushButton->setIcon(icon);
        newAccount_pushButton->setIconSize(QSize(45, 45));
        DepositToAccount_pushButton = new QPushButton(OperationMelatBankSystem);
        DepositToAccount_pushButton->setObjectName(QString::fromUtf8("DepositToAccount_pushButton"));
        DepositToAccount_pushButton->setGeometry(QRect(370, 270, 321, 71));
        DepositToAccount_pushButton->setFont(font);
        DepositToAccount_pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        DepositToAccount_pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 170, 255);\n"
"color: rgb(255, 255, 255);"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/pref2/deposit.png"), QSize(), QIcon::Normal, QIcon::Off);
        DepositToAccount_pushButton->setIcon(icon1);
        DepositToAccount_pushButton->setIconSize(QSize(45, 45));
        harvest_pushButton = new QPushButton(OperationMelatBankSystem);
        harvest_pushButton->setObjectName(QString::fromUtf8("harvest_pushButton"));
        harvest_pushButton->setGeometry(QRect(30, 270, 321, 71));
        harvest_pushButton->setFont(font);
        harvest_pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        harvest_pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 170, 255);"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/pref1/bardasht.png"), QSize(), QIcon::Normal, QIcon::Off);
        harvest_pushButton->setIcon(icon2);
        harvest_pushButton->setIconSize(QSize(45, 45));
        InventorAccount_pushButton = new QPushButton(OperationMelatBankSystem);
        InventorAccount_pushButton->setObjectName(QString::fromUtf8("InventorAccount_pushButton"));
        InventorAccount_pushButton->setGeometry(QRect(710, 350, 321, 71));
        InventorAccount_pushButton->setFont(font);
        InventorAccount_pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        InventorAccount_pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 170, 255);"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/pref1/money account.png"), QSize(), QIcon::Normal, QIcon::Off);
        InventorAccount_pushButton->setIcon(icon3);
        InventorAccount_pushButton->setIconSize(QSize(45, 45));
        showInformation_pushButton = new QPushButton(OperationMelatBankSystem);
        showInformation_pushButton->setObjectName(QString::fromUtf8("showInformation_pushButton"));
        showInformation_pushButton->setGeometry(QRect(370, 350, 321, 71));
        showInformation_pushButton->setFont(font);
        showInformation_pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        showInformation_pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 170, 255);"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/pref2/information.png"), QSize(), QIcon::Normal, QIcon::Off);
        showInformation_pushButton->setIcon(icon4);
        showInformation_pushButton->setIconSize(QSize(45, 45));
        DeleteAccount_pushButton = new QPushButton(OperationMelatBankSystem);
        DeleteAccount_pushButton->setObjectName(QString::fromUtf8("DeleteAccount_pushButton"));
        DeleteAccount_pushButton->setGeometry(QRect(30, 350, 321, 71));
        DeleteAccount_pushButton->setFont(font);
        DeleteAccount_pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        DeleteAccount_pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 170, 255);"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/pref2/delete acc.png"), QSize(), QIcon::Normal, QIcon::Off);
        DeleteAccount_pushButton->setIcon(icon5);
        DeleteAccount_pushButton->setIconSize(QSize(45, 45));
        EditAccount_pushButton = new QPushButton(OperationMelatBankSystem);
        EditAccount_pushButton->setObjectName(QString::fromUtf8("EditAccount_pushButton"));
        EditAccount_pushButton->setGeometry(QRect(370, 430, 321, 71));
        EditAccount_pushButton->setFont(font);
        EditAccount_pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        EditAccount_pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(85, 170, 255);"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/pref2/edit.png"), QSize(), QIcon::Normal, QIcon::Off);
        EditAccount_pushButton->setIcon(icon6);
        EditAccount_pushButton->setIconSize(QSize(45, 45));
        Close_pushButton = new QPushButton(OperationMelatBankSystem);
        Close_pushButton->setObjectName(QString::fromUtf8("Close_pushButton"));
        Close_pushButton->setGeometry(QRect(30, 510, 321, 71));
        Close_pushButton->setFont(font);
        Close_pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        Close_pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 0, 0);"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/pref1/close.png"), QSize(), QIcon::Normal, QIcon::Off);
        Close_pushButton->setIcon(icon7);
        Close_pushButton->setIconSize(QSize(45, 45));
        Back_pushButton = new QPushButton(OperationMelatBankSystem);
        Back_pushButton->setObjectName(QString::fromUtf8("Back_pushButton"));
        Back_pushButton->setGeometry(QRect(710, 510, 321, 71));
        Back_pushButton->setFont(font);
        Back_pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        Back_pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 169, 48);"));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/pref1/backk.png"), QSize(), QIcon::Normal, QIcon::Off);
        Back_pushButton->setIcon(icon8);
        Back_pushButton->setIconSize(QSize(50, 50));
        EmployeeInformation_pushButton = new QPushButton(OperationMelatBankSystem);
        EmployeeInformation_pushButton->setObjectName(QString::fromUtf8("EmployeeInformation_pushButton"));
        EmployeeInformation_pushButton->setGeometry(QRect(710, 430, 321, 71));
        EmployeeInformation_pushButton->setFont(font);
        EmployeeInformation_pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        EmployeeInformation_pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 170, 255);"));
        EmployeeInformation_pushButton->setIcon(icon8);
        EmployeeInformation_pushButton->setIconSize(QSize(50, 50));
        programmer_pushButton = new QPushButton(OperationMelatBankSystem);
        programmer_pushButton->setObjectName(QString::fromUtf8("programmer_pushButton"));
        programmer_pushButton->setGeometry(QRect(30, 430, 321, 71));
        programmer_pushButton->setFont(font);
        programmer_pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        programmer_pushButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 170, 255);"));
        programmer_pushButton->setIcon(icon8);
        programmer_pushButton->setIconSize(QSize(50, 50));

        retranslateUi(OperationMelatBankSystem);

        QMetaObject::connectSlotsByName(OperationMelatBankSystem);
    } // setupUi

    void retranslateUi(QDialog *OperationMelatBankSystem)
    {
        OperationMelatBankSystem->setWindowTitle(QApplication::translate("OperationMelatBankSystem", "Dialog", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        label_3->setText(QString());
        label_4->setText(QApplication::translate("OperationMelatBankSystem", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; color:#ffffff;\">\331\204\330\267\331\201\330\247 \330\271\331\205\331\204\333\214\330\247\330\252 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261 \330\261\330\247 \330\247\331\206\330\252\330\256\330\247\330\250 \332\251\331\206\333\214\330\257</span></p></body></html>", nullptr));
        newAccount_pushButton->setText(QApplication::translate("OperationMelatBankSystem", "\330\247\333\214\330\254\330\247\330\257 \330\255\330\263\330\247\330\250 \330\254\330\257\333\214\330\257", nullptr));
        DepositToAccount_pushButton->setText(QApplication::translate("OperationMelatBankSystem", "\331\210\330\247\330\261\333\214\330\262 \330\250\331\207 \333\214\332\251 \330\255\330\263\330\247\330\250", nullptr));
        harvest_pushButton->setText(QApplication::translate("OperationMelatBankSystem", "\330\250\330\261\330\257\330\247\330\264\330\252 \330\247\330\262 \333\214\332\251 \330\255\330\263\330\247\330\250", nullptr));
        InventorAccount_pushButton->setText(QApplication::translate("OperationMelatBankSystem", "\330\257\330\261\330\256\331\210\330\247\330\263\330\252 \331\205\331\210\330\254\331\210\330\257\333\214", nullptr));
        showInformation_pushButton->setText(QApplication::translate("OperationMelatBankSystem", "\331\206\331\205\330\247\333\214\330\264 \330\247\330\267\331\204\330\247\330\271\330\247\330\252 \332\251\330\247\330\261\330\250\330\261\330\247\331\206", nullptr));
        DeleteAccount_pushButton->setText(QApplication::translate("OperationMelatBankSystem", "\330\255\330\260\331\201 \333\214\332\251 \330\255\330\263\330\247\330\250", nullptr));
        EditAccount_pushButton->setText(QApplication::translate("OperationMelatBankSystem", "\330\247\330\265\331\204\330\247\330\255 \331\205\330\264\330\256\330\265\330\247\330\252 \333\214\332\251 \330\255\330\263\330\247\330\250", nullptr));
        Close_pushButton->setText(QApplication::translate("OperationMelatBankSystem", "\330\256\330\261\331\210\330\254", nullptr));
        Back_pushButton->setText(QApplication::translate("OperationMelatBankSystem", "\330\250\330\261\332\257\330\264\330\252", nullptr));
        EmployeeInformation_pushButton->setText(QApplication::translate("OperationMelatBankSystem", "\331\205\330\264\330\256\330\265\330\247\330\252 \332\251\330\247\330\261\331\205\331\206\330\257\330\247\331\206", nullptr));
        programmer_pushButton->setText(QApplication::translate("OperationMelatBankSystem", "\330\250\330\261\331\206\330\247\331\205\331\207 \331\206\331\210\333\214\330\263", nullptr));
    } // retranslateUi

};

namespace Ui {
    class OperationMelatBankSystem: public Ui_OperationMelatBankSystem {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OPERATIONMELATBANKSYSTEM_H
