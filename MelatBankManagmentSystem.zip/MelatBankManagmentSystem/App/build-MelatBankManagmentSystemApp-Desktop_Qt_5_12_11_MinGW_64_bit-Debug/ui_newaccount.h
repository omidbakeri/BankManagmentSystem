/********************************************************************************
** Form generated from reading UI file 'newaccount.ui'
**
** Created by: Qt User Interface Compiler version 5.12.11
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWACCOUNT_H
#define UI_NEWACCOUNT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_NewAccount
{
public:
    QLabel *label;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLineEdit *nameLineEdit;
    QLabel *label_10;
    QLineEdit *lstnameLineEdit;
    QLineEdit *nationalcodeLineEdit;
    QLineEdit *fathernameLineEdit;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLineEdit *numberofAccountLineEdit;
    QLineEdit *shomareCartLineEdit;
    QLineEdit *mojodiLineEdit;
    QRadioButton *jariRadioButton;
    QRadioButton *GhRadioButton;
    QPushButton *confirmationPushButton;
    QPushButton *backPushButton;
    QPushButton *closePushButton;
    QLineEdit *dayLineEdit;
    QLineEdit *monthLineEdit;
    QLineEdit *yearLineEdit;
    QLabel *label_14;

    void setupUi(QDialog *NewAccount)
    {
        if (NewAccount->objectName().isEmpty())
            NewAccount->setObjectName(QString::fromUtf8("NewAccount"));
        NewAccount->setEnabled(true);
        NewAccount->resize(1062, 638);
        NewAccount->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);"));
        label = new QLabel(NewAccount);
        label->setObjectName(QString::fromUtf8("label"));
        label->setEnabled(true);
        label->setGeometry(QRect(20, 20, 1031, 161));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_3 = new QLabel(NewAccount);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(350, 50, 327, 110));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/pref2/bank melat.jpg")));
        label_3->setScaledContents(true);
        label_2 = new QLabel(NewAccount);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setEnabled(true);
        label_2->setGeometry(QRect(20, 190, 1031, 431));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(88, 88, 88);"));
        label_4 = new QLabel(NewAccount);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 200, 1001, 411));
        label_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_5 = new QLabel(NewAccount);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(860, 220, 151, 31));
        label_5->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_6 = new QLabel(NewAccount);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(860, 260, 151, 31));
        label_6->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_7 = new QLabel(NewAccount);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(860, 300, 151, 31));
        label_7->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_8 = new QLabel(NewAccount);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(860, 340, 151, 31));
        label_8->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_9 = new QLabel(NewAccount);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(860, 380, 151, 31));
        label_9->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        nameLineEdit = new QLineEdit(NewAccount);
        nameLineEdit->setObjectName(QString::fromUtf8("nameLineEdit"));
        nameLineEdit->setGeometry(QRect(640, 220, 211, 31));
        nameLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        label_10 = new QLabel(NewAccount);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(290, 220, 151, 31));
        label_10->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        lstnameLineEdit = new QLineEdit(NewAccount);
        lstnameLineEdit->setObjectName(QString::fromUtf8("lstnameLineEdit"));
        lstnameLineEdit->setGeometry(QRect(640, 260, 211, 31));
        lstnameLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        nationalcodeLineEdit = new QLineEdit(NewAccount);
        nationalcodeLineEdit->setObjectName(QString::fromUtf8("nationalcodeLineEdit"));
        nationalcodeLineEdit->setGeometry(QRect(640, 340, 211, 31));
        nationalcodeLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        fathernameLineEdit = new QLineEdit(NewAccount);
        fathernameLineEdit->setObjectName(QString::fromUtf8("fathernameLineEdit"));
        fathernameLineEdit->setGeometry(QRect(640, 380, 211, 31));
        fathernameLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        label_11 = new QLabel(NewAccount);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(290, 280, 151, 31));
        label_11->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_12 = new QLabel(NewAccount);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(290, 340, 151, 31));
        label_12->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_13 = new QLabel(NewAccount);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(290, 380, 151, 31));
        label_13->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        numberofAccountLineEdit = new QLineEdit(NewAccount);
        numberofAccountLineEdit->setObjectName(QString::fromUtf8("numberofAccountLineEdit"));
        numberofAccountLineEdit->setGeometry(QRect(70, 220, 211, 31));
        numberofAccountLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        shomareCartLineEdit = new QLineEdit(NewAccount);
        shomareCartLineEdit->setObjectName(QString::fromUtf8("shomareCartLineEdit"));
        shomareCartLineEdit->setGeometry(QRect(70, 340, 211, 31));
        shomareCartLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        mojodiLineEdit = new QLineEdit(NewAccount);
        mojodiLineEdit->setObjectName(QString::fromUtf8("mojodiLineEdit"));
        mojodiLineEdit->setGeometry(QRect(130, 380, 151, 31));
        mojodiLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        jariRadioButton = new QRadioButton(NewAccount);
        jariRadioButton->setObjectName(QString::fromUtf8("jariRadioButton"));
        jariRadioButton->setGeometry(QRect(170, 280, 82, 17));
        jariRadioButton->setCursor(QCursor(Qt::PointingHandCursor));
        jariRadioButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        GhRadioButton = new QRadioButton(NewAccount);
        GhRadioButton->setObjectName(QString::fromUtf8("GhRadioButton"));
        GhRadioButton->setGeometry(QRect(170, 300, 111, 21));
        GhRadioButton->setCursor(QCursor(Qt::PointingHandCursor));
        GhRadioButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        confirmationPushButton = new QPushButton(NewAccount);
        confirmationPushButton->setObjectName(QString::fromUtf8("confirmationPushButton"));
        confirmationPushButton->setGeometry(QRect(70, 540, 131, 61));
        confirmationPushButton->setCursor(QCursor(Qt::PointingHandCursor));
        confirmationPushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 170, 0);\n"
"font: 12pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        backPushButton = new QPushButton(NewAccount);
        backPushButton->setObjectName(QString::fromUtf8("backPushButton"));
        backPushButton->setGeometry(QRect(210, 540, 131, 61));
        backPushButton->setCursor(QCursor(Qt::PointingHandCursor));
        backPushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 170, 0);\n"
"background-color: rgb(255, 173, 41);\n"
"font: 12pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        closePushButton = new QPushButton(NewAccount);
        closePushButton->setObjectName(QString::fromUtf8("closePushButton"));
        closePushButton->setGeometry(QRect(350, 540, 131, 61));
        closePushButton->setCursor(QCursor(Qt::PointingHandCursor));
        closePushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 170, 0);\n"
"background-color: rgb(255, 0, 0);\n"
"font: 12pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        dayLineEdit = new QLineEdit(NewAccount);
        dayLineEdit->setObjectName(QString::fromUtf8("dayLineEdit"));
        dayLineEdit->setGeometry(QRect(790, 300, 61, 31));
        dayLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        monthLineEdit = new QLineEdit(NewAccount);
        monthLineEdit->setObjectName(QString::fromUtf8("monthLineEdit"));
        monthLineEdit->setGeometry(QRect(720, 300, 61, 31));
        monthLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        yearLineEdit = new QLineEdit(NewAccount);
        yearLineEdit->setObjectName(QString::fromUtf8("yearLineEdit"));
        yearLineEdit->setGeometry(QRect(640, 300, 61, 31));
        yearLineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 56, 167);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        label_14 = new QLabel(NewAccount);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(66, 380, 61, 31));
        label_14->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        label->raise();
        label_2->raise();
        label_4->raise();
        label_5->raise();
        label_6->raise();
        label_7->raise();
        label_8->raise();
        label_9->raise();
        nameLineEdit->raise();
        label_10->raise();
        lstnameLineEdit->raise();
        nationalcodeLineEdit->raise();
        fathernameLineEdit->raise();
        label_11->raise();
        label_12->raise();
        label_13->raise();
        numberofAccountLineEdit->raise();
        shomareCartLineEdit->raise();
        mojodiLineEdit->raise();
        label_3->raise();
        jariRadioButton->raise();
        GhRadioButton->raise();
        confirmationPushButton->raise();
        backPushButton->raise();
        closePushButton->raise();
        dayLineEdit->raise();
        monthLineEdit->raise();
        yearLineEdit->raise();
        label_14->raise();

        retranslateUi(NewAccount);

        QMetaObject::connectSlotsByName(NewAccount);
    } // setupUi

    void retranslateUi(QDialog *NewAccount)
    {
        NewAccount->setWindowTitle(QApplication::translate("NewAccount", "Dialog", nullptr));
        label->setText(QString());
        label_3->setText(QString());
        label_2->setText(QString());
        label_4->setText(QApplication::translate("NewAccount", "\330\261\333\214\330\247\331\204", nullptr));
        label_5->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\331\206\330\247\331\205</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\331\206\330\247\331\205 \330\256\330\247\331\206\331\210\330\247\330\257\332\257\333\214</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\">\330\252\330\247\330\261\333\214\330\256 \330\252\331\210\331\204\330\257</p></body></html>", nullptr));
        label_8->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\332\251\330\257 \331\205\331\204\333\214</span></p></body></html>", nullptr));
        label_9->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\331\206\330\247\331\205 \331\276\330\257\330\261</span></p></body></html>", nullptr));
        label_10->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\">\330\264\331\205\330\247\330\261\331\207 \330\255\330\263\330\247\330\250</p></body></html>", nullptr));
        label_11->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\331\206\331\210\330\271 \330\255\330\263\330\247\330\250</span></p></body></html>", nullptr));
        label_12->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\330\264\331\205\330\247\330\261\331\207 \332\251\330\247\330\261\330\252</span></p></body></html>", nullptr));
        label_13->setText(QApplication::translate("NewAccount", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">\331\205\331\210\330\254\331\210\330\257\333\214 \330\255\330\263\330\247\330\250</span></p></body></html>", nullptr));
        jariRadioButton->setText(QApplication::translate("NewAccount", "\330\254\330\247\330\261\333\214", nullptr));
        GhRadioButton->setText(QApplication::translate("NewAccount", "\331\202\330\261\330\266 \330\247\331\204\330\256\330\263\331\206\331\207", nullptr));
        confirmationPushButton->setText(QApplication::translate("NewAccount", "\330\252\330\247\333\214\333\214\330\257", nullptr));
        backPushButton->setText(QApplication::translate("NewAccount", "\330\250\330\261\332\257\330\264\330\252", nullptr));
        closePushButton->setText(QApplication::translate("NewAccount", "\330\256\330\261\331\210\330\254", nullptr));
        label_14->setText(QApplication::translate("NewAccount", "\330\261\333\214\330\247\331\204", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NewAccount: public Ui_NewAccount {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWACCOUNT_H
